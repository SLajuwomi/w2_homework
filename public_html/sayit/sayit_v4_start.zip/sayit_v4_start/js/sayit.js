// sayit.js
$(document).ready(function(){
	$("#update").click(function(){
		location.reload(true);
	});
});
